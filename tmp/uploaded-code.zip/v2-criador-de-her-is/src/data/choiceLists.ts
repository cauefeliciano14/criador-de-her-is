/**
 * Catálogos de opções para escolhas genéricas (idiomas, ferramentas, instrumentos, etc.).
 *
 * Observação: este projeto trabalha em PT-BR e prioriza o PHB 2024.
 * As listas abaixo são deliberadamente "conservadoras" (itens comuns) e podem ser expandidas
 * conforme os dados oficiais forem completados.
 */

import { races } from "./races";
import { backgrounds } from "./backgrounds";

function isPlaceholderChoice(text: string): boolean {
  const t = text.toLowerCase();
  return t.includes("à sua escolha") || t.includes("a sua escolha") || t.includes("adicional à sua escolha");
}

/** Idiomas conhecidos no dataset + alguns comuns do PHB. */
export const LANGUAGE_OPTIONS: string[] = (() => {
  const set = new Set<string>();
  // Collect fixed languages from races/backgrounds
  for (const r of races) {
    for (const l of r.languages ?? []) {
      if (!l) continue;
      if (isPlaceholderChoice(l)) continue;
      set.add(l);
    }
  }
  for (const b of backgrounds) {
    for (const l of b.languages ?? []) {
      if (!l) continue;
      if (isPlaceholderChoice(l)) continue;
      set.add(l);
    }
  }

  // Add a small conservative baseline of common languages.
  // (Only added if not already present.)
  [
    "Comum",
    "Anão",
    "Élfico",
    "Dracônico",
    "Infernal",
    "Abissal",
    "Celestial",
    "Gigante",
    "Gnômico",
    "Orc",
  ].forEach((l) => set.add(l));

  return [...set].sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));
})();

export const MUSICAL_INSTRUMENT_OPTIONS: string[] = [
  "Alaúde",
  "Flauta",
  "Flauta de Pã",
  "Gaita",
  "Harpa",
  "Lira",
  "Tambor",
  "Trombeta",
  "Violino",
].sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));

export const ARTISAN_TOOL_OPTIONS: string[] = [
  "Ferramentas de Alquimista",
  "Ferramentas de Cervejeiro",
  "Ferramentas de Calígrafo",
  "Ferramentas de Carpinteiro",
  "Ferramentas de Cartógrafo",
  "Ferramentas de Curtidor",
  "Ferramentas de Ferreiro",
  "Ferramentas de Joalheiro",
  "Ferramentas de Oleiro",
  "Ferramentas de Pedreiro",
  "Ferramentas de Pintor",
  "Ferramentas de Sapateiro",
  "Ferramentas de Tecelão",
  "Ferramentas de Vidreiro",
  "Ferramentas de Entalhador",
].sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));

export const GAME_SET_OPTIONS: string[] = [
  "Dados",
  "Cartas",
  "Xadrez",
  "Gamão",
].sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));

/**
 * Lista unificada para a escolha genérica de "Ferramenta" quando a fonte diz
 * "Uma ferramenta de artesão ou instrumento musical".
 */
export const TOOL_OR_INSTRUMENT_OPTIONS: string[] = [
  ...ARTISAN_TOOL_OPTIONS,
  ...MUSICAL_INSTRUMENT_OPTIONS,
].sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));
