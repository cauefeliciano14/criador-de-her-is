import { classes } from "@/data/classes";
import { races } from "@/data/races";
import { backgrounds } from "@/data/backgrounds";
import type { CharacterState } from "@/state/characterStore";

export interface ParsedChoiceCounts {
  languageChoices: number;
  toolChoices: {
    musicalInstruments: number;
    artisanTools: number;
    gameSets: number;
    toolOrInstrument: number;
  };
  fixedLanguages: string[];
  fixedTools: string[];
}

function normalize(s: string): string {
  return (s ?? "").trim();
}

function isLanguagePlaceholder(s: string): boolean {
  const t = s.toLowerCase();
  return t.includes("idioma") && (t.includes("à sua escolha") || t.includes("a sua escolha"));
}

function languagePlaceholderCount(s: string): number {
  const t = s.toLowerCase();
  if (!isLanguagePlaceholder(s)) return 0;
  if (t.includes("dois")) return 2;
  if (t.includes("três") || t.includes("tres")) return 3;
  return 1;
}

function toolPlaceholderCounts(s: string): ParsedChoiceCounts["toolChoices"] {
  const t = s.toLowerCase();
  const out = { musicalInstruments: 0, artisanTools: 0, gameSets: 0, toolOrInstrument: 0 };

  // Instruments
  if (t.includes("instrument")) {
    if (t.includes("três") || t.includes("tres")) out.musicalInstruments += 3;
    else if (t.includes("dois")) out.musicalInstruments += 2;
    else if (t.includes("um")) out.musicalInstruments += 1;
    else out.musicalInstruments += 1;
  }

  // Artisan tools
  if (t.includes("ferramenta") && t.includes("artes") && t.includes("um tipo")) {
    out.artisanTools += 1;
  }

  // Game sets
  if (t.includes("tipo de jogo")) {
    out.gameSets += 1;
  }

  // Either/or
  if (t.includes("ferramenta") && t.includes("artes") && t.includes("ou") && t.includes("instrument")) {
    out.toolOrInstrument += 1;
    // Avoid double counting when this exact line also includes the patterns above
    out.musicalInstruments = 0;
    out.artisanTools = 0;
  }

  return out;
}

function sumToolCounts(a: ParsedChoiceCounts["toolChoices"], b: ParsedChoiceCounts["toolChoices"]) {
  return {
    musicalInstruments: a.musicalInstruments + b.musicalInstruments,
    artisanTools: a.artisanTools + b.artisanTools,
    gameSets: a.gameSets + b.gameSets,
    toolOrInstrument: a.toolOrInstrument + b.toolOrInstrument,
  };
}

function isToolPlaceholder(s: string): boolean {
  const t = s.toLowerCase();
  if (t.includes("instrument")) return true;
  if (t.includes("um tipo") && t.includes("ferramenta") && t.includes("artes")) return true;
  if (t.includes("tipo de jogo")) return true;
  if (t.includes("ferramenta") && t.includes("artes") && t.includes("ou") && t.includes("instrument")) return true;
  return false;
}

/**
 * Extrai contagens de escolhas e lista de proficiências fixas (idiomas/ferramentas)
 * a partir de Classe + Raça + Antecedente.
 */
export function getProficiencyChoiceCounts(char: CharacterState): ParsedChoiceCounts {
  const cls = classes.find((c) => c.id === char.class);
  const race = races.find((r) => r.id === char.race);
  const bg = backgrounds.find((b) => b.id === char.background);

  let languageChoices = 0;
  let fixedLanguages: string[] = [];

  const languageSources = [
    ...(race?.languages ?? []),
    ...(race?.subraces?.find((sr) => sr.id === char.subrace)?.languages ?? []),
    ...(bg?.languages ?? []),
    ...(cls?.proficiencies.languages ?? []),
  ].map(normalize).filter(Boolean);

  for (const l of languageSources) {
    const c = languagePlaceholderCount(l);
    if (c > 0) languageChoices += c;
    else fixedLanguages.push(l);
  }

  let toolCounts = { musicalInstruments: 0, artisanTools: 0, gameSets: 0, toolOrInstrument: 0 };
  let fixedTools: string[] = [];

  const toolSources = [
    ...(bg?.tools ?? []),
    ...(cls?.proficiencies.tools ?? []),
    ...(race?.proficiencies?.tools ?? []),
    ...(race?.subraces?.find((sr) => sr.id === char.subrace)?.proficiencies?.tools ?? []),
  ].map(normalize).filter(Boolean);

  for (const t of toolSources) {
    if (isToolPlaceholder(t)) {
      toolCounts = sumToolCounts(toolCounts, toolPlaceholderCounts(t));
    } else {
      fixedTools.push(t);
    }
  }

  // Dedup fixed lists
  fixedLanguages = Array.from(new Set(fixedLanguages));
  fixedTools = Array.from(new Set(fixedTools));

  return {
    languageChoices,
    toolChoices: toolCounts,
    fixedLanguages,
    fixedTools,
  };
}

/**
 * Rebuild only languages/tools proficiencies (armor/weapons stay as-is).
 * This keeps the app from persisting placeholder strings like "Um idioma à sua escolha".
 */
export function deriveLanguageAndToolProficiencies(char: CharacterState): {
  languages: string[];
  tools: string[];
} {
  const counts = getProficiencyChoiceCounts(char);

  const chosenLanguages = (char.choiceSelections?.languages ?? []).map(normalize).filter(Boolean);
  const chosenTools = (char.choiceSelections?.tools ?? []).map(normalize).filter(Boolean);

  const languages = Array.from(new Set([...counts.fixedLanguages, ...chosenLanguages])).sort((a, b) =>
    a.localeCompare(b, "pt-BR", { sensitivity: "base" })
  );

  const tools = Array.from(new Set([...counts.fixedTools, ...chosenTools])).sort((a, b) =>
    a.localeCompare(b, "pt-BR", { sensitivity: "base" })
  );

  return { languages, tools };
}
