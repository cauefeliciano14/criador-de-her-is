import type { CharacterState } from "@/state/characterStore";
import { classes } from "@/data/classes";
import { races } from "@/data/races";
import { backgrounds } from "@/data/backgrounds";
import { spellsByClassName } from "@/data/indexes";
import { calcAbilityMod, getFinalAbilityScores, type AbilityKey } from "@/utils/calculations";
import {
  LANGUAGE_OPTIONS,
  MUSICAL_INSTRUMENT_OPTIONS,
  ARTISAN_TOOL_OPTIONS,
  GAME_SET_OPTIONS,
  TOOL_OR_INSTRUMENT_OPTIONS,
} from "@/data/choiceLists";
import { getProficiencyChoiceCounts } from "@/utils/proficiencyChoices";

export interface ChoicesBlock<TId extends string = string> {
  requiredCount: number;
  chosenIds: TId[];
  options: { id: TId; name: string; source?: string }[];
  pendingCount: number;
}

export interface ChoicesRequirements {
  needsStep: boolean;
  skills: ChoicesBlock<string>;
  languages: ChoicesBlock<string>;
  tools: ChoicesBlock<string> & {
    breakdown: {
      musicalInstruments: number;
      artisanTools: number;
      gameSets: number;
      toolOrInstrument: number;
    };
  };
  cantrips: {
    requiredCount: number;
    chosenSpellIds: string[];
    options: string[]; // spellIds
    pendingCount: number;
  };
  spells: {
    requiredCount: number;
    chosenSpellIds: string[];
    options: string[]; // spellIds
    pendingCount: number;
  };
}

function getCantripsLimit(table: Record<number, number>, level: number): number {
  for (let l = level; l >= 1; l--) {
    if (table[l] !== undefined) return table[l];
  }
  return 0;
}

export function getChoicesRequirements(char: CharacterState): ChoicesRequirements {
  const cls = classes.find((c) => c.id === char.class);
  const race = races.find((r) => r.id === char.race);
  const bg = backgrounds.find((b) => b.id === char.background);

  // ── Skills requirements (class skill choices) ──
  const skillsRequired = cls?.skillChoices?.choose ?? 0;
  const skillsChosen = char.classSkillChoices || [];
  const skillsOptions = (cls?.skillChoices?.from ?? []).map((name) => ({
    id: name,
    name,
    source: "Classe",
  }));
  const skillsPending = Math.max(0, skillsRequired - skillsChosen.length);

  // ── Generic language/tool choice requirements ──
  const counts = getProficiencyChoiceCounts(char);

  const languageRequired = counts.languageChoices;
  const languageChosen = (char.choiceSelections?.languages ?? []).slice(0);
  const languageOptions = LANGUAGE_OPTIONS.map((l) => ({ id: l, name: l }));
  const languagePending = Math.max(0, languageRequired - languageChosen.length);

  const toolRequired =
    counts.toolChoices.musicalInstruments +
    counts.toolChoices.artisanTools +
    counts.toolChoices.gameSets +
    counts.toolChoices.toolOrInstrument;

  const toolChosen = (char.choiceSelections?.tools ?? []).slice(0);

  // Options: we present all, but we also add a short label prefix in UI.
  // The raw id is the same as display name.
  const toolOptions = [
    ...MUSICAL_INSTRUMENT_OPTIONS.map((n) => ({ id: n, name: `Instrumento: ${n}` })),
    ...ARTISAN_TOOL_OPTIONS.map((n) => ({ id: n, name: `Ferramenta: ${n}` })),
    ...GAME_SET_OPTIONS.map((n) => ({ id: n, name: `Jogo: ${n}` })),
    ...TOOL_OR_INSTRUMENT_OPTIONS.map((n) => ({ id: n, name: `Opção (Ferramenta/Instrumento): ${n}` })),
  ];
  const toolPending = Math.max(0, toolRequired - toolChosen.length);

  // ── Spellcasting requirements ──
  let cantripsRequired = 0;
  let cantripsChosen: string[] = [];
  let cantripsOptions: string[] = [];

  let spellsRequired = 0;
  let spellsChosen: string[] = [];
  let spellsOptions: string[] = [];

  if (cls?.spellcasting) {
    const sc = cls.spellcasting;

    // cantrips limit
    let cantripsLimit = getCantripsLimit(sc.cantripsKnownAtLevel, char.level);

    // class feature choices that add +1 cantrip
    const cfc = char.classFeatureChoices ?? {};
    if (char.class === "clerigo" && cfc["clerigo:ordemDivina"] === "taumaturgo") cantripsLimit += 1;
    if (char.class === "druida" && cfc["druida:ordemPrimal"] === "xama") cantripsLimit += 1;

    cantripsRequired = cantripsLimit;
    cantripsChosen = char.spells.cantrips || [];

    // IMPORTANT: spellsByClassName is keyed by class name (PT-BR), not by id.
    const classSpells = spellsByClassName[cls.name] || [];
    cantripsOptions = classSpells.filter((s) => s.level === 0).map((s) => s.id);

    // spells required
    const abilityMap: Record<string, AbilityKey> = {
      Força: "str",
      Destreza: "dex",
      Constituição: "con",
      Inteligência: "int",
      Sabedoria: "wis",
      Carisma: "cha",
    };

    const scKey = abilityMap[sc.ability] ?? null;
    const finalScores = getFinalAbilityScores(
      char.abilityScores,
      char.racialBonuses,
      char.backgroundBonuses,
      char.asiBonuses,
      char.featAbilityBonuses
    );
    const scMod = scKey ? calcAbilityMod(finalScores[scKey]) : 0;

    if (sc.type === "prepared") {
      spellsRequired = Math.max(1, scMod + char.level);
    } else {
      const knownTable = (sc as any).spellsKnownAtLevel as Record<number, number> | undefined;
      if (knownTable) {
        for (let l = char.level; l >= 1; l--) {
          if (knownTable[l] !== undefined) {
            spellsRequired = knownTable[l];
            break;
          }
        }
      }
    }

    spellsChosen = char.spells.prepared || [];

    // Levels supported now: 1–2. So spells are cantrips or 1st circle.
    const maxSpellLevel = 1;
    spellsOptions = classSpells.filter((s) => s.level > 0 && s.level <= maxSpellLevel).map((s) => s.id);
  }

  const cantripsPending = Math.max(0, cantripsRequired - cantripsChosen.length);
  const spellsPending = Math.max(0, spellsRequired - spellsChosen.length);

  const needsStep =
    skillsPending > 0 ||
    languagePending > 0 ||
    toolPending > 0 ||
    cantripsPending > 0 ||
    spellsPending > 0;

  return {
    needsStep,
    skills: {
      requiredCount: skillsRequired,
      chosenIds: skillsChosen,
      options: skillsOptions,
      pendingCount: skillsPending,
    },
    languages: {
      requiredCount: languageRequired,
      chosenIds: languageChosen,
      options: languageOptions,
      pendingCount: languagePending,
    },
    tools: {
      requiredCount: toolRequired,
      chosenIds: toolChosen,
      options: toolOptions,
      pendingCount: toolPending,
      breakdown: { ...counts.toolChoices },
    },
    cantrips: {
      requiredCount: cantripsRequired,
      chosenSpellIds: cantripsChosen,
      options: cantripsOptions,
      pendingCount: cantripsPending,
    },
    spells: {
      requiredCount: spellsRequired,
      chosenSpellIds: spellsChosen,
      options: spellsOptions,
      pendingCount: spellsPending,
    },
  };
}
