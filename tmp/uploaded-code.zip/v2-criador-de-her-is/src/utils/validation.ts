import type { CharacterState } from "@/state/characterStore";
import { races } from "@/data/races";
import { classes } from "@/data/classes";
import { backgrounds } from "@/data/backgrounds";
import type { AbilityKey } from "@/utils/calculations";
import { getChoicesRequirements } from "@/utils/choices";
import {
  MUSICAL_INSTRUMENT_OPTIONS,
  ARTISAN_TOOL_OPTIONS,
  GAME_SET_OPTIONS,
  TOOL_OR_INSTRUMENT_OPTIONS,
} from "@/data/choiceLists";

export interface ValidationItem {
  id: string;
  label: string;
  stepId: string;
  stepNumber: number;
  severity: "required" | "warning";
  details?: string;
}

export interface ValidationResult {
  isComplete: boolean;
  missing: ValidationItem[];
  warnings: ValidationItem[];
}

export function validateCharacterCompleteness(char: CharacterState): ValidationResult {
  const missing: ValidationItem[] = [];
  const warnings: ValidationItem[] = [];

  const race = races.find((r) => r.id === char.race);
  const cls = classes.find((c) => c.id === char.class);
  const bg = backgrounds.find((b) => b.id === char.background);

  const req = getChoicesRequirements(char);
  const hasChoicesStep = req.needsStep;

  const stepNum = (id: string): number => {
    const mapBase: Record<string, number> = {
      class: 1,
      origin: 2,
      race: 3,
      abilities: 4,
      equipment: 5,
      sheet: 6,
    };
    const mapWithChoices: Record<string, number> = {
      class: 1,
      origin: 2,
      race: 3,
      abilities: 4,
      choices: 5,
      equipment: 6,
      sheet: 7,
    };
    return (hasChoicesStep ? mapWithChoices : mapBase)[id] ?? 0;
  };

  // ── Classe ──
  if (!char.class) {
    missing.push({
      id: "class-select",
      label: "Classe não selecionada",
      stepId: "class",
      stepNumber: stepNum("class"),
      severity: "required",
    });
  } else if (cls) {
    // Subclass required (future-proof)
    if (
      cls.subclassLevel != null &&
      cls.subclasses.length > 0 &&
      char.level >= cls.subclassLevel &&
      !char.subclass
    ) {
      missing.push({
        id: "subclass-select",
        label: `Subclasse obrigatória no nível ${cls.subclassLevel}`,
        stepId: "class",
        stepNumber: stepNum("class"),
        severity: "required",
      });
    }

    // Class feature choices (lvl 1–2)
    const cfc = char.classFeatureChoices ?? {};
    if (char.class === "clerigo" && !cfc["clerigo:ordemDivina"]) {
      missing.push({
        id: "clerigo-ordem-divina",
        label: "Ordem Divina não escolhida (Clérigo)",
        stepId: "class",
        stepNumber: stepNum("class"),
        severity: "required",
      });
    }
    if (char.class === "druida" && !cfc["druida:ordemPrimal"]) {
      missing.push({
        id: "druida-ordem-primal",
        label: "Ordem Primal não escolhida (Druida)",
        stepId: "class",
        stepNumber: stepNum("class"),
        severity: "required",
      });
    }

    // Expertise validations
    const expertiseChecks: { key: string; count: number; label: string; minLevel: number }[] = [
      { key: "ladino:especialista", count: 2, label: "Especialização do Ladino", minLevel: 1 },
      { key: "bardo:especialista", count: 2, label: "Especialização do Bardo", minLevel: 2 },
      { key: "guardiao:exploradorHabil:especialista", count: 1, label: "Explorador Hábil (Guardião)", minLevel: 2 },
      { key: "mago:academico", count: 1, label: "Acadêmico (Mago)", minLevel: 2 },
    ];
    for (const check of expertiseChecks) {
      if (char.class !== check.key.split(":")[0]) continue;
      if (char.level < check.minLevel) continue;
      const val = cfc[check.key];
      const chosen = Array.isArray(val) ? val.length : typeof val === "string" ? 1 : 0;
      if (chosen < check.count) {
        missing.push({
          id: `expertise-${check.key}`,
          label: `${check.label}: ${chosen}/${check.count} escolhido(s)`,
          stepId: hasChoicesStep ? "choices" : "sheet",
          stepNumber: stepNum(hasChoicesStep ? "choices" : "sheet"),
          severity: "required",
        });
      }
    }
  }

  // ── Origem ──
  if (!char.background) {
    missing.push({
      id: "bg-select",
      label: "Antecedente não selecionado",
      stepId: "origin",
      stepNumber: stepNum("origin"),
      severity: "required",
    });
  }

  // Origin feat (required)
  if (bg) {
    const hasFeat = char.features.some(
      (f) => f.sourceType === "background" && f.tags?.includes("originFeat")
    );
    if (!hasFeat) {
      missing.push({
        id: "origin-feat",
        label: "Talento de Origem não aplicado",
        stepId: "origin",
        stepNumber: stepNum("origin"),
        severity: "required",
      });
    }
  }

  // ── Raça ──
  if (!char.race) {
    missing.push({
      id: "race-select",
      label: "Raça não selecionada",
      stepId: "race",
      stepNumber: stepNum("race"),
      severity: "required",
    });
  } else if (race && race.subraces.length > 0 && !char.subrace) {
    missing.push({
      id: "subrace-select",
      label: "Sub-raça obrigatória não selecionada",
      stepId: "race",
      stepNumber: stepNum("race"),
      severity: "required",
    });
  }

  // Race ability choices
  if (race?.abilityBonuses.mode === "choose" && race.abilityBonuses.choose) {
    const choicesNeeded = race.abilityBonuses.choose.choices;
    const chosen = Object.keys(char.raceAbilityChoices ?? {}).filter(
      (k) => (char.raceAbilityChoices as any)[k] > 0
    ).length;
    if (chosen < choicesNeeded) {
      missing.push({
        id: "race-ability-choices",
        label: `Bônus de atributo da raça incompletos (${chosen}/${choicesNeeded})`,
        stepId: "race",
        stepNumber: stepNum("race"),
        severity: "required",
      });
    }
  }

  // ── Atributos ──
  if (!char.abilityGeneration.method || !char.abilityGeneration.confirmed) {
    missing.push({
      id: "ability-method",
      label: "Método de atributos não selecionado ou não confirmado",
      stepId: "abilities",
      stepNumber: stepNum("abilities"),
      severity: "required",
    });
  }

  // Background ability choices (if any)
  if (bg?.abilityBonuses.mode === "choose" && bg.abilityBonuses.choose) {
    const choicesNeeded = bg.abilityBonuses.choose.choices;
    const chosen = Object.keys(char.backgroundAbilityChoices ?? {}).filter(
      (k) => (char.backgroundAbilityChoices as any)[k] > 0
    ).length;
    if (chosen < choicesNeeded) {
      missing.push({
        id: "bg-ability-choices",
        label: `Bônus de atributo do antecedente incompletos (${chosen}/${choicesNeeded})`,
        stepId: "abilities",
        stepNumber: stepNum("abilities"),
        severity: "required",
      });
    }
  }

  // ── Escolhas (Perícias/Truques/Magias + Idiomas/Ferramentas) ──
  if (hasChoicesStep) {
    // Skills
    if (req.skills.pendingCount > 0) {
      missing.push({
        id: "choices-skills",
        label: `Perícias pendentes (${req.skills.chosenIds.length}/${req.skills.requiredCount})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }

    // Languages
    if (req.languages.pendingCount > 0) {
      missing.push({
        id: "choices-languages",
        label: `Idiomas pendentes (${req.languages.chosenIds.length}/${req.languages.requiredCount})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }

    // Tools breakdown
    const chosenTools = char.choiceSelections?.tools ?? [];
    const instr = chosenTools.filter((t) => MUSICAL_INSTRUMENT_OPTIONS.includes(t)).length;
    const artisan = chosenTools.filter((t) => ARTISAN_TOOL_OPTIONS.includes(t)).length;
    const games = chosenTools.filter((t) => GAME_SET_OPTIONS.includes(t)).length;
    const either = chosenTools.filter((t) => TOOL_OR_INSTRUMENT_OPTIONS.includes(t)).length;

    const b = req.tools.breakdown;
    if (b.musicalInstruments > 0 && instr < b.musicalInstruments) {
      missing.push({
        id: "choices-instruments",
        label: `Instrumentos pendentes (${instr}/${b.musicalInstruments})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }
    if (b.artisanTools > 0 && artisan < b.artisanTools) {
      missing.push({
        id: "choices-artisan-tools",
        label: `Ferramentas de Artesão pendentes (${artisan}/${b.artisanTools})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }
    if (b.gameSets > 0 && games < b.gameSets) {
      missing.push({
        id: "choices-games",
        label: `Jogos pendentes (${games}/${b.gameSets})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }
    if (b.toolOrInstrument > 0 && either < b.toolOrInstrument) {
      missing.push({
        id: "choices-tool-or-instrument",
        label: `Ferramenta/Instrumento pendente (${either}/${b.toolOrInstrument})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }

    // Cantrips/Spells
    if (req.cantrips.pendingCount > 0) {
      missing.push({
        id: "choices-cantrips",
        label: `Truques pendentes (${req.cantrips.chosenSpellIds.length}/${req.cantrips.requiredCount})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }
    if (req.spells.pendingCount > 0) {
      missing.push({
        id: "choices-spells",
        label: `Magias pendentes (${req.spells.chosenSpellIds.length}/${req.spells.requiredCount})`,
        stepId: "choices",
        stepNumber: stepNum("choices"),
        severity: "required",
      });
    }
  }

  // ── Equipamentos ──
  if (cls && cls.equipmentChoices.length > 0 && !char.classEquipmentChoice) {
    missing.push({
      id: "equipment-choice",
      label: "Equipamento inicial (A/B) não escolhido",
      stepId: "equipment",
      stepNumber: stepNum("equipment"),
      severity: "required",
    });
  }

  return {
    isComplete: missing.length === 0,
    missing,
    warnings,
  };
}
