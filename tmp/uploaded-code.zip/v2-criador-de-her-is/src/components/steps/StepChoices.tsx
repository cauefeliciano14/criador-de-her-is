import { useEffect, useMemo, useState } from "react";
import { useCharacterStore } from "@/state/characterStore";
import { useBuilderStore } from "@/state/builderStore";
import { classes } from "@/data/classes";
import { spells } from "@/data/spells";
import {
  LANGUAGE_OPTIONS,
  MUSICAL_INSTRUMENT_OPTIONS,
  ARTISAN_TOOL_OPTIONS,
  GAME_SET_OPTIONS,
  TOOL_OR_INSTRUMENT_OPTIONS,
} from "@/data/choiceLists";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Shield,
  Sparkles,
  BookOpen,
  Globe,
  Wrench,
  Dice5,
  Music,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

const LEVEL_LABELS: Record<number, string> = {
  0: "Truque",
  1: "1º Círculo",
  2: "2º Círculo",
  3: "3º Círculo",
  4: "4º Círculo",
  5: "5º Círculo",
  6: "6º Círculo",
  7: "7º Círculo",
  8: "8º Círculo",
  9: "9º Círculo",
};

function uniq<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

export function StepChoices() {
  const char = useCharacterStore();
  const patchCharacter = useCharacterStore((s) => s.patchCharacter);

  const completeStep = useBuilderStore((s) => s.completeStep);
  const uncompleteStep = useBuilderStore((s) => s.uncompleteStep);
  const setMissing = useBuilderStore((s) => s.setMissing);
  const choicesRequirements = useBuilderStore((s) => s.choicesRequirements);

  const cls = classes.find((c) => c.id === char.class);

  // Keep requirements up-to-date
  useEffect(() => {
    useBuilderStore.getState().updateChoicesRequirements();
  }, [
    char.class,
    char.race,
    char.subrace,
    char.background,
    char.level,
    char.classSkillChoices,
    char.choiceSelections.languages,
    char.choiceSelections.tools,
    char.spells.cantrips,
    char.spells.prepared,
    char.classFeatureChoices,
  ]);

  const req = choicesRequirements;
  if (!req) return null;

  // Search for spells
  const [spellSearch, setSpellSearch] = useState("");

  const spellById = useMemo(() => {
    const m: Record<string, (typeof spells)[number]> = {};
    for (const s of spells) m[s.id] = s;
    return m;
  }, []);

  const missingList = useMemo(() => {
    const list: string[] = [];
    if (req.skills.pendingCount > 0) list.push(`Perícias: faltam ${req.skills.pendingCount}`);
    if (req.languages.pendingCount > 0) list.push(`Idiomas: faltam ${req.languages.pendingCount}`);

    // tools breakdown
    const b = req.tools.breakdown;
    const chosenTools = char.choiceSelections.tools ?? [];
    const chosenInstr = chosenTools.filter((t) => MUSICAL_INSTRUMENT_OPTIONS.includes(t)).length;
    const chosenArtisan = chosenTools.filter((t) => ARTISAN_TOOL_OPTIONS.includes(t)).length;
    const chosenGames = chosenTools.filter((t) => GAME_SET_OPTIONS.includes(t)).length;
    const chosenEither = chosenTools.filter((t) => TOOL_OR_INSTRUMENT_OPTIONS.includes(t)).length;

    if (b.musicalInstruments > 0 && chosenInstr < b.musicalInstruments) {
      list.push(`Instrumentos: faltam ${b.musicalInstruments - chosenInstr}`);
    }
    if (b.artisanTools > 0 && chosenArtisan < b.artisanTools) {
      list.push(`Ferramentas de Artesão: faltam ${b.artisanTools - chosenArtisan}`);
    }
    if (b.gameSets > 0 && chosenGames < b.gameSets) {
      list.push(`Jogos: faltam ${b.gameSets - chosenGames}`);
    }
    if (b.toolOrInstrument > 0 && chosenEither < b.toolOrInstrument) {
      list.push(`Ferramenta/Instrumento: faltam ${b.toolOrInstrument - chosenEither}`);
    }

    if (req.cantrips.pendingCount > 0) list.push(`Truques: faltam ${req.cantrips.pendingCount}`);
    if (req.spells.pendingCount > 0) list.push(`Magias: faltam ${req.spells.pendingCount}`);

    return list;
  }, [req, char.choiceSelections.tools]);

  const isComplete = missingList.length === 0;

  useEffect(() => {
    setMissing("choices", missingList);
    if (isComplete) completeStep("choices");
    else uncompleteStep("choices");
  }, [isComplete, missingList.join("|"), setMissing, completeStep, uncompleteStep]);

  // ── Helpers ──

  const toggleLimited = (arr: string[], value: string, max: number): string[] => {
    if (arr.includes(value)) return arr.filter((v) => v !== value);
    if (arr.length >= max) return arr;
    return [...arr, value];
  };

  const setLanguages = (next: string[]) => {
    patchCharacter({
      choiceSelections: {
        ...char.choiceSelections,
        languages: next,
      },
    });
  };

  const setTools = (next: string[]) => {
    patchCharacter({
      choiceSelections: {
        ...char.choiceSelections,
        tools: next,
      },
    });
  };

  // ── Section: Skills ──

  const skillsSection = () => {
    if (req.skills.requiredCount <= 0) return null;

    const options = [...req.skills.options]
      .map((o) => o.id)
      .sort((a, b) => a.localeCompare(b, "pt-BR", { sensitivity: "base" }));

    const selected = char.classSkillChoices ?? [];
    const remaining = Math.max(0, req.skills.requiredCount - selected.length);

    return (
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Perícias</h3>
          <Badge variant="outline">{selected.length}/{req.skills.requiredCount}</Badge>
          {remaining > 0 && <Badge variant="secondary">faltam {remaining}</Badge>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {options.map((skill) => {
            const isSelected = selected.includes(skill);
            return (
              <button
                key={skill}
                onClick={() => {
                  const next = toggleLimited(selected, skill, req.skills.requiredCount);
                  patchCharacter({ classSkillChoices: next });
                }}
                className={`p-3 rounded-lg border text-left transition-colors ${
                  isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted border-border"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{skill}</span>
                  {isSelected ? (
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                  ) : (
                    <CircleIcon />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  // ── Section: Languages ──

  const languagesSection = () => {
    if (req.languages.requiredCount <= 0) return null;

    const selected = char.choiceSelections.languages ?? [];
    const remaining = Math.max(0, req.languages.requiredCount - selected.length);

    return (
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Idiomas</h3>
          <Badge variant="outline">{selected.length}/{req.languages.requiredCount}</Badge>
          {remaining > 0 && <Badge variant="secondary">faltam {remaining}</Badge>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {LANGUAGE_OPTIONS.map((lang) => {
            const isSelected = selected.includes(lang);
            return (
              <button
                key={lang}
                onClick={() => setLanguages(toggleLimited(selected, lang, req.languages.requiredCount))}
                className={`p-3 rounded-lg border text-left transition-colors ${
                  isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted border-border"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{lang}</span>
                  {isSelected ? (
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                  ) : (
                    <CircleIcon />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  // ── Section: Tools/Instrumentos/Jogos ──

  const toolsSection = () => {
    const b = req.tools.breakdown;
    const totalRequired = req.tools.requiredCount;
    if (totalRequired <= 0) return null;

    const chosen = char.choiceSelections.tools ?? [];

    const chosenInstr = chosen.filter((t) => MUSICAL_INSTRUMENT_OPTIONS.includes(t));
    const chosenArtisan = chosen.filter((t) => ARTISAN_TOOL_OPTIONS.includes(t));
    const chosenGames = chosen.filter((t) => GAME_SET_OPTIONS.includes(t));
    const chosenEither = chosen.filter((t) => TOOL_OR_INSTRUMENT_OPTIONS.includes(t));

    return (
      <div className="rounded-lg border bg-card p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Ferramentas & Instrumentos</h3>
          <Badge variant="outline">{chosen.length}/{totalRequired}</Badge>
        </div>

        {b.musicalInstruments > 0 && (
          <ChoiceGrid
            icon={<Music className="h-4 w-4" />}
            title="Instrumentos Musicais"
            required={b.musicalInstruments}
            options={MUSICAL_INSTRUMENT_OPTIONS}
            selected={chosenInstr}
            onChange={(next) => {
              const other = chosen.filter((t) => !MUSICAL_INSTRUMENT_OPTIONS.includes(t));
              setTools(uniq([...other, ...next]));
            }}
          />
        )}

        {b.artisanTools > 0 && (
          <ChoiceGrid
            icon={<Wrench className="h-4 w-4" />}
            title="Ferramentas de Artesão"
            required={b.artisanTools}
            options={ARTISAN_TOOL_OPTIONS}
            selected={chosenArtisan}
            onChange={(next) => {
              const other = chosen.filter((t) => !ARTISAN_TOOL_OPTIONS.includes(t));
              setTools(uniq([...other, ...next]));
            }}
          />
        )}

        {b.gameSets > 0 && (
          <ChoiceGrid
            icon={<Dice5 className="h-4 w-4" />}
            title="Jogos"
            required={b.gameSets}
            options={GAME_SET_OPTIONS}
            selected={chosenGames}
            onChange={(next) => {
              const other = chosen.filter((t) => !GAME_SET_OPTIONS.includes(t));
              setTools(uniq([...other, ...next]));
            }}
          />
        )}

        {b.toolOrInstrument > 0 && (
          <ChoiceGrid
            icon={<Wrench className="h-4 w-4" />}
            title="Ferramenta de Artesão OU Instrumento"
            required={b.toolOrInstrument}
            options={TOOL_OR_INSTRUMENT_OPTIONS}
            selected={chosenEither}
            onChange={(next) => {
              const other = chosen.filter((t) => !TOOL_OR_INSTRUMENT_OPTIONS.includes(t));
              setTools(uniq([...other, ...next]));
            }}
          />
        )}
      </div>
    );
  };

  // ── Section: Cantrips ──

  const cantripsSection = () => {
    if (req.cantrips.requiredCount <= 0) return null;

    const selected = char.spells.cantrips ?? [];
    const remaining = Math.max(0, req.cantrips.requiredCount - selected.length);
    const options = req.cantrips.options
      .map((id) => spellById[id])
      .filter(Boolean)
      .filter((s) => s.name.toLowerCase().includes(spellSearch.trim().toLowerCase()));

    return (
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Truques</h3>
          <Badge variant="outline">{selected.length}/{req.cantrips.requiredCount}</Badge>
          {remaining > 0 && <Badge variant="secondary">faltam {remaining}</Badge>}
        </div>

        <Input
          value={spellSearch}
          onChange={(e) => setSpellSearch(e.target.value)}
          placeholder="Buscar truques/magias..."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {options.map((spell) => {
            const isSelected = selected.includes(spell.id);
            return (
              <button
                key={spell.id}
                onClick={() => {
                  const next = toggleLimited(selected, spell.id, req.cantrips.requiredCount);
                  patchCharacter({ spells: { ...char.spells, cantrips: next } });
                }}
                className={`p-3 rounded-lg border text-left transition-colors ${
                  isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted border-border"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{spell.name}</span>
                  <Badge variant="secondary" className="text-xs">{LEVEL_LABELS[spell.level]}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{spell.school}</p>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  // ── Section: Spells ──

  const spellsSection = () => {
    if (req.spells.requiredCount <= 0) return null;

    const selected = char.spells.prepared ?? [];
    const remaining = Math.max(0, req.spells.requiredCount - selected.length);

    const options = req.spells.options
      .map((id) => spellById[id])
      .filter(Boolean)
      .filter((s) => s.name.toLowerCase().includes(spellSearch.trim().toLowerCase()));

    return (
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Magias</h3>
          <Badge variant="outline">{selected.length}/{req.spells.requiredCount}</Badge>
          {remaining > 0 && <Badge variant="secondary">faltam {remaining}</Badge>}
        </div>

        <Input
          value={spellSearch}
          onChange={(e) => setSpellSearch(e.target.value)}
          placeholder="Buscar truques/magias..."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {options.map((spell) => {
            const isSelected = selected.includes(spell.id);
            return (
              <button
                key={spell.id}
                onClick={() => {
                  const next = toggleLimited(selected, spell.id, req.spells.requiredCount);
                  patchCharacter({ spells: { ...char.spells, prepared: next } });
                }}
                className={`p-3 rounded-lg border text-left transition-colors ${
                  isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted border-border"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{spell.name}</span>
                  <Badge variant="secondary" className="text-xs">{LEVEL_LABELS[spell.level]}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{spell.school}</p>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">5. Escolhas</h2>
          <p className="text-sm text-muted-foreground">
            Esta etapa só aparece quando sua Classe/Raça/Origem exige escolhas do jogador.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isComplete ? (
            <Badge className="bg-success text-success-foreground gap-1">
              <CheckCircle2 className="h-3 w-3" /> Completo
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1 text-muted-foreground">
              <AlertCircle className="h-3 w-3" /> {missingList.length} pendência(s)
            </Badge>
          )}
        </div>
      </div>

      {missingList.length > 0 && (
        <div className="rounded-lg border border-info/30 bg-info/5 p-4">
          <div className="flex items-center gap-2 text-info mb-2">
            <AlertCircle className="h-4 w-4" />
            <span className="font-semibold text-sm">Pendências obrigatórias</span>
          </div>
          <ul className="space-y-1">
            {missingList.map((m) => (
              <li key={m} className="text-sm text-muted-foreground">• {m}</li>
            ))}
          </ul>
        </div>
      )}

      {skillsSection()}
      {languagesSection()}
      {toolsSection()}
      {cantripsSection()}
      {spellsSection()}
    </div>
  );
}

function CircleIcon() {
  return <span className="inline-block h-4 w-4 rounded-full border border-muted-foreground/40" />;
}

function ChoiceGrid({
  icon,
  title,
  required,
  options,
  selected,
  onChange,
}: {
  icon: React.ReactNode;
  title: string;
  required: number;
  options: string[];
  selected: string[];
  onChange: (next: string[]) => void;
}) {
  const remaining = Math.max(0, required - selected.length);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <span className="text-muted-foreground">{icon}</span>
        <h4 className="text-sm font-semibold">{title}</h4>
        <Badge variant="outline">{selected.length}/{required}</Badge>
        {remaining > 0 && <Badge variant="secondary">faltam {remaining}</Badge>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {options.map((opt) => {
          const isSelected = selected.includes(opt);
          const canAdd = selected.length < required;
          return (
            <button
              key={opt}
              onClick={() => {
                if (isSelected) onChange(selected.filter((s) => s !== opt));
                else if (canAdd) onChange([...selected, opt]);
              }}
              className={`p-3 rounded-lg border text-left transition-colors ${
                isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted border-border"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">{opt}</span>
                {isSelected ? (
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                ) : (
                  <CircleIcon />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
