import { useCharacterStore } from "@/state/characterStore";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function IdentityHeader() {
  const name = useCharacterStore((s) => s.name);
  const level = useCharacterStore((s) => s.level);
  const patchCharacter = useCharacterStore((s) => s.patchCharacter);
  const setStartLevel = useCharacterStore((s) => s.setStartLevel);

  const handleNameChange = (value: string) => {
    patchCharacter({ name: value });
  };

  const handleLevelChange = (value: string) => {
    const newLevel = parseInt(value);
    if (newLevel === 1 || newLevel === 2) setStartLevel(newLevel);
  };

  return (
    <div className="border-b bg-card px-6 py-4">
      <div className="max-w-md">
        <h3 className="text-sm font-semibold mb-3">Identidade do Personagem</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="character-name" className="text-xs">Nome</Label>
            <Input
              id="character-name"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="Nome do personagem"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="character-level" className="text-xs">Nível Inicial</Label>
            <Select value={level.toString()} onValueChange={handleLevelChange}>
              <SelectTrigger id="character-level" className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Nível 1</SelectItem>
                <SelectItem value="2">Nível 2</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}